"""
Queremos realizar un programa que calcule o índice dunha chave para un dicionario utilizando o algoritmo de hashing por folding. 
O programa recibirá en orde os seguintes parámetros: tamaño da táboa, número de división por folding e a chave.
"""

__author__ = "Aitor Novoa Alonso"

def hashing_por_folding(tamaño_tabla, divisiones, clave):
    """
    Calcula el índice de una clave para un diccionario usando el algoritmo de hashing por folding, solo utilizando cadenas de texto.
    
    Args:
        tamaño_tabla (int): El tamaño de la tabla de hash (número de buckets).
        divisiones (int): Número de divisiones por folding.
        clave (str): La clave que se usará para calcular el índice.
    
    Returns:
        int: El índice calculado para la clave en la tabla de hash.
    """
    
    tamaño_parte = len(clave) // divisiones
    suma_partes = 0
    
    for i in range(divisiones):
        parte = clave[i * tamaño_parte: (i + 1) * tamaño_parte]
        
        # if i == divisiones - 1:
        #     parte = clave[i * tamaño_parte:]
        
        for char in parte:
            suma_partes += ord(char)
    
    indice = suma_partes % tamaño_tabla
    return indice



tamaño_tabla = int(input("Introduce el tamaño de la tabla de hash: "))
divisiones = int(input("Introduce el número de divisiones por folding: "))
clave = input("Introduce la clave: ")
        
indice = hashing_por_folding(tamaño_tabla, divisiones, clave)
        
print(f"El índice calculado para la clave '{clave}' es: {indice}")
    

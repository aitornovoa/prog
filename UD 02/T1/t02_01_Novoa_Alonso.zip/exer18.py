"""
Escribe un script que pida ao usuario 3 números e móstralle por pantalla a media dos 3 números
"""

__auth__="Aitor Novoa Alonso"

numero1 = float(input("Introduce el primer numero: "))
numero2 = float(input("Introduce el segundo numero: "))
numero3 = float(input("Introduce el tercero numero: "))

media = (numero1+numero2+numero3)/3

print(f"La media de los 3 numeros es {media}")

